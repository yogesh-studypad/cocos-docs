# 如何使用控件
通过本章的学习，您将了解到每个控件使用的场景、方法以及如何自定义这些控件。

[按钮](../basic-controls/button/zh.md)
[复选框](../basic-controls/checkbox/zh.md)
[精灵](../basic-controls/sprite/zh.md)
[图片](../basic-controls/image/zh.md)
[艺术数字](../basic-controls/atlaslabel/zh.md)
[FNT字体](../basic-controls/bitmaplabel/zh.md)
[进度条](../basic-controls/progressbar/zh.md)
[滑动条](../basic-controls/slider/zh.md)
[文本](../basic-controls/label/zh.md)
[输入框](../basic-controls/button/zh.md)
[粒子](../basic-controls/particle/zh.md)
[地图](../basic-controls/button/zh.md)
[声音](../basic-controls/button/zh.md)
[节点](../basic-controls/button/zh.md)